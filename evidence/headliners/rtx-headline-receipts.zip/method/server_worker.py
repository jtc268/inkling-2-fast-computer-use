import json,sys
from pathlib import Path
root=Path(__file__).resolve().parents[4]
sys.path.insert(0,str(root/'work/publication/inkling-browser-weights/benchmark'))
from cuda_worker import CudaWorker
system='Operate the browser using the numbered controls in the observation. Work efficiently. Respond directly with the actions, one per line. A fill is F <id> <value>. A button click is C <id>. Use only the provided IDs. No commentary.'
w=CudaWorker('http://127.0.0.1:31951',root/'work/publication/model',{'device':'RTX 5090','engine':'SGLang'},384)
w.decide_web('Click Go. Controls: 7 button Go.',system);print('READY',flush=True)
for line in sys.stdin:
 print(json.dumps(w.decide_web(json.loads(line)['prompt'],system)),flush=True)
