import json,os,sys,subprocess,time,urllib.request
from pathlib import Path
here=Path(__file__).resolve().parent;root=here.parents[3];repo=root/'work/publication/inkling-browser-weights'
sys.path.insert(0,str(repo/'benchmark'));import gym as suite
from remote import call
out=here/'runs';os.environ['MINIWOB_URL']=(root/'work/browsergym/miniwob/miniwob/html/miniwob').as_uri()+'/'
ep='http://127.0.0.1:31951'
def signal(key):
 call('linux',"from pathlib import Path\nPath('/var/tmp/inkling-wa-20261120/linux-headliners.command').write_text("+repr(key)+")",check=True)
def wait_model(key):
 for i in range(290):
  if i%20==0:signal(key)
  try:
   if json.load(urllib.request.urlopen(ep+'/v1/models',timeout=2))['data'][0]['id']=='inkling-headliners-'+key:return
  except OSError:pass
  time.sleep(1)
 raise TimeoutError(key)
try:
 for key,arm in [('original','original'),('candidate','edited')]:
  wait_model(key)
  while not (here.parent/'cdp-runs/done.json').is_file():time.sleep(2)
  cases=json.loads((here.parent/'cdp-runs/done.json').read_text())
  for task,seed in cases:
   with urllib.request.urlopen(ep+'/flush_cache?timeout=8',timeout=12) as f:assert 'Cache flushed' in f.read().decode()
   w=subprocess.Popen([str(repo/'.venv/bin/python'),str(here/'server_worker.py')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True,env={**os.environ,'HF_HUB_OFFLINE':'1'})
   try:
    assert w.stdout.readline().strip()=='READY'
    suite.evaluate(task,seed,arm,w,out)
   finally:
    w.stdin.close();w.wait()
  if key=='original':(here/'original-done.json').write_text(json.dumps(cases))
 (here/'done.json').write_text(json.dumps(cases))
finally:signal('stop')
