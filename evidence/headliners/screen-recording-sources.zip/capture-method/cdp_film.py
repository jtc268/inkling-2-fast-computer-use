"""Render native live screenshots on their measured wall clock and archive all capture input."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import bisect,hashlib,json,math,subprocess,textwrap
import numpy as np
from PIL import Image,ImageDraw
from film import here,out,font,fps
dest=here/'cdp-runs'
cases=json.loads((dest/'done.json').read_text());films=[]
archive=out/'screen-recording-sources.zip'
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=2) as z:
 for p in sorted(dest.rglob('*')):
  if p.suffix in ('.png','.json') and p.is_file():z.write(p,p.relative_to(dest))
 for name in ('record_cdp.py','cdp-watch.mjs','cdp_film.py','film.py'):z.write(here/name,'capture-method/'+name)
for task,seed in cases:
 title,name={'use-autocomplete':('Complete an autocomplete field','autocomplete'), 'email-inbox':('Reply to an email','email-reply')}[task]
 arms=[json.loads((dest/f'{task}-{seed}-{arm}.json').read_text()) for arm in ['original','edited']]
 if not all(r['success'] and r.get('reward',0)>0 for r in arms):continue
 assert arms[0]['goal']==arms[1]['goal']
 def clock(rec):
  folder=dest/f"{task}-{seed}-{rec['arm']}";manifest=json.loads((folder/'frames.json').read_text())
  origin=rec['capture_start_unix_s'];elapsed=rec['elapsed_s'];ends=[v['end']/1000-origin for v in manifest]
  assert ends[0]<=0 and ends[-1]+.001>=elapsed,(ends[0],elapsed,ends[-1])
  gap=max(b-a for a,b in zip(ends,ends[1:]));assert gap<1.0,(gap,rec['arm'])
  return folder,manifest,ends,dict(wall_s=elapsed,raw_sha256=hashlib.sha256((folder/'frames.json').read_bytes()).hexdigest(),source='Timestamped CDP screenshots of the entire 160×210 CSS-pixel task surface',frames=len(manifest),max_frame_interval_s=gap)
 streams=[clock(r) for r in arms];width,height=984,852
 film=out/(name+'.mp4')
 enc=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s',f'{width}x{height}','-r',str(fps),'-i','-','-an','-c:v','libx264','-preset','veryfast','-crf','16','-pix_fmt','yuv420p','-movflags','+faststart',str(film)],stdin=subprocess.PIPE)
 last=[None,None];index=[-1,-1]
 for i in range(math.ceil(max(r['elapsed_s'] for r in arms)*fps)+fps+1):
  t=i/fps;img=Image.new('RGB',(width,height),'#101719');d=ImageDraw.Draw(img)
  d.text((30,16),title,font=font(43,True),fill='#f5faf8')
  detail=f'BrowserGym MiniWoB++  ·  Seed {seed}  ·  Brave on M5 Max MacBook Pro  ·  1×'
  d.text((32,80),detail,font=font(23),fill='#bfcbc7')
  for k,row in enumerate(textwrap.wrap(arms[0]['goal'],width=72)):
   d.text((32,121+31*k),row,font=font(26),fill='#e3ebe7')
  for j,(folder,frames,ends,meta) in enumerate(streams):
   duration=meta['wall_s'];done=t>=duration
   ix=(min(len(ends)-1,bisect.bisect_left(ends,duration)) if done else max(0,bisect.bisect_right(ends,t)-1))
   if ix!=index[j]:
    with Image.open(folder/frames[ix]['file']) as im:
     im=im.convert('RGB')
     # BrowserGym briefly overrides device scale for an observation. Keep the
     # whole native task at one scale even when CDP adds a grey outer margin.
     band=np.asarray(im)[8,:,:]
     yellow=np.flatnonzero((band[:,0]>205)&(band[:,1]>185)&(band[:,2]<72))
     if not len(yellow):raise ValueError(f'Cannot identify task surface in {frames[ix]["file"]}')
     w=int(yellow[-1])+1
     if not 150<=w<=im.width:raise ValueError(f'Unexpected captured surface width {w}')
     last[j]=im.crop((0,0,w,min(im.height,round(w*210/160)))).resize((400,525),Image.Resampling.LANCZOS)
    index[j]=ix
   x=(32,524)[j];d.text((x,212),('Original Inkling 2 Mini','Two-row weight edit')[j],font=font(28,True),fill='#eaf3ee')
   img.paste(last[j],(x,259))
   d.text((x,798),('Verified  ·  ' if done else '')+f'{min(t,duration):.2f} s',font=font(31,True),fill='#92ecc3' if done else '#e3ebe7')
  if i==round(min(r['elapsed_s'] for r in arms)*fps)+8:img.resize((680,589),Image.Resampling.LANCZOS).save(here/(name+'-preview.jpg'))
  enc.stdin.write(img.tobytes())
 enc.stdin.close()
 if enc.wait():raise RuntimeError('ffmpeg encoder failed')
 films.append(dict(file=film.name,selection=detail,playback=1,arms=[s[-1] for s in streams],sha256=hashlib.sha256(film.read_bytes()).hexdigest(),ratio=arms[0]['elapsed_s']/arms[1]['elapsed_s'],display='Full native MiniWoB task surface, sampled up to eight frames per second and displayed at original speed'))
(out/'gym-videos.json').write_text(json.dumps(films,indent=2)+'\n')
