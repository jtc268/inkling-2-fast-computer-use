"""Render full, clock-aligned browser recordings at 1× for the headline examples."""
import hashlib,json,math,subprocess
from functools import lru_cache
from pathlib import Path
from statistics import median
from PIL import Image,ImageDraw,ImageFont
here=Path(__file__).resolve().parent;root=here.parents[2];out=root/'outputs/browser-headliners'
fps=25;width=960
@lru_cache(None)
def font(n,bold=False):
 return ImageFont.truetype('/System/Library/Fonts/Avenir Next.ttc',n,index=0 if bold else 5)
def probe(path):
 return json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=width,height:format=duration','-of','json',str(path)]))
def start_end(path):
 pixels=subprocess.check_output(['ffmpeg','-v','error','-i',str(path),'-vf','fps=25,crop=4:4:2:2,scale=1:1','-pix_fmt','rgb24','-f','rawvideo','-'])
 colors=list(zip(pixels[::3],pixels[1::3],pixels[2::3]))
 green=next(i for i,(r,g,b) in enumerate(colors) if r<75 and g>170 and 55<b<185)
 pink=next((i for i,(r,g,b) in enumerate(colors) if i>green and r>185 and g<90 and b>100),None)
 return green,pink
def submitted_frame(path,approx):
 # Selenium's receipt has two lines at the top and an empty body. Identify the
 # first actual receipt frame near the measured submission, then visually verify it.
 from PIL import Image
 start=max(0,approx-3);count=26
 buf=subprocess.check_output(['ffmpeg','-v','error','-i',str(path),'-vf',f'fps=25,trim=start_frame={start},scale=256:170','-frames:v',str(count),'-pix_fmt','gray','-f','rawvideo','-'])
 for i in range(len(buf)//(256*170)):
  im=Image.frombytes('L',(256,170),buf[i*256*170:(i+1)*256*170])
  top=sum(im.crop((6,0,110,16)).histogram()[:190]);second=sum(im.crop((6,16,105,33)).histogram()[:210]);lower=sum(im.crop((6,37,246,162)).histogram()[:220])
  if top>12 and second>2 and lower<6:return start+i
 raise ValueError('Selenium confirmation page was not captured')
def render(filename,title,detail,paths,wall,stage):
 inputs=[probe(p)['streams'][0] for p in paths];assert inputs[0]==inputs[1]
 w,h=inputs[0]['width'],inputs[0]['height'];view_w=width-44;view_h=round(view_w*h/w)
 header=112;unit=66+view_h+18;H=2*math.ceil((header+2*unit+18)/2)
 clips=[];meta=[]
 for p,elapsed in zip(paths,wall):
  start,end=start_end(p)
  if stage:end=submitted_frame(p,start+round(elapsed*fps))
  if end is None:raise RuntimeError(f'Missing completion marker in {p}')
  span=(end-start)/fps
  if abs(span-elapsed)>1.2:raise RuntimeError(f'Timing uncertainty {p.name}: {span:.2f} vs {elapsed:.2f}')
  meta.append(dict(raw_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),start_frame=start,end_frame=end,wall_s=elapsed,frame_span_s=span))
  vf=f'fps={fps},trim=start_frame={start},drawbox=x=0:y=0:w={24 if stage else 8}:h=8:color=white:t=fill'
  dec=subprocess.Popen(['ffmpeg','-v','error','-i',str(p),'-vf',vf,'-frames:v',str(end-start+1),'-pix_fmt','rgb24','-f','rawvideo','-'],stdout=subprocess.PIPE)
  clips.append(dec)
 dest=out/filename
 enc=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s',f'{width}x{H}','-r',str(fps),'-i','-','-an','-c:v','libx264','-preset','veryfast','-crf','16','-pix_fmt','yuv420p','-movflags','+faststart',str(dest)],stdin=subprocess.PIPE)
 last=[None,None]
 for i in range(max(m['end_frame']-m['start_frame'] for m in meta)+1+fps):
  canvas=Image.new('RGB',(width,H),'#101719');draw=ImageDraw.Draw(canvas)
  draw.text((22,7),title,font=font(42,True),fill='#f6faf9')
  draw.text((23,67),detail,font=font(24),fill='#c0cecc')
  for j,(dec,m) in enumerate(zip(clips,meta)):
   span=m['end_frame']-m['start_frame'];done=i>=span
   if i<=span:
    f=dec.stdout.read(w*h*3)
    if len(f)==w*h*3:last[j]=Image.frombytes('RGB',(w,h),f).resize((view_w,view_h),Image.Resampling.LANCZOS)
   if last[j] is None:raise RuntimeError('No video frames')
   top=header+unit*j
   draw.text((22,top),['Original Inkling 2 Mini','Two-row weight edit'][j],font=font(30,True),fill='#eef5f3')
   elapsed=m['wall_s'] if done else min(i/fps,m['wall_s'])
   draw.text((width-22,top+2),('Verified   ' if done else '')+f'{elapsed:05.2f} s',anchor='ra',font=font(28),fill='#8ee9be' if done else '#eef5f3')
   canvas.paste(last[j],(22,top+55))
  if i==int(min(wall)*fps)+10:canvas.resize((440,round(H*440/width)),Image.Resampling.LANCZOS).save(here/(dest.stem+'-preview.jpg'))
  enc.stdin.write(canvas.tobytes())
 enc.stdin.close();assert enc.wait()==0
 for c in clips:c.stdout.close();c.wait()
 return dict(file=filename,selection=detail,playback=1,arms=meta,sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),ratio=wall[0]/wall[1])
def form():
 d=root/'work/ten/form-control/runs';pairs=[]
 for c in range(1,7):
  key=f'{c:02}';v=[json.loads((d/f'{key}-{a}.json').read_text()) for a in ['original','release_swap']]
  pairs.append((key,[r['form_s'] for r in v]))
 center=median(w[0] for _,w in pairs)/median(w[1] for _,w in pairs)
 key,wall=min(pairs,key=lambda p:abs(p[1][0]/p[1][1]-center))
 return render('form-submit.mp4','Fill and submit a form',f'Selenium  ·  Case {key}  ·  Brave on M5 Max MacBook Pro  ·  1×',[d/f'{key}-{a}.webm' for a in ('original','release_swap')],wall,True)
if __name__=='__main__':
 import sys
 if sys.argv[1]=='form':
  (out/'form-video.json').write_text(json.dumps(form(),indent=2)+'\n')
 else:
  d=here/'runs';available=[]
  for task,seed in [('use-autocomplete',n) for n in (101,102,103,104)]+[('email-inbox',104)]:
   arms=['original','edited']; stems=[f'{task}-{seed}-{a}' for a in arms];rs=[json.loads((d/(stem+'.json')).read_text()) for stem in stems]
   if all(r['success'] and r.get('reward',0)>0 for r in rs):available.append((task,seed,[d/stem/'live.webm' for stem in stems],[r['elapsed_s'] for r in rs]))
  films=[]
  for task,title,filename in [('use-autocomplete','Complete an autocomplete field','autocomplete.mp4'),('email-inbox','Reply to an email','email-reply.mp4')]:
   wins=[a for a in available if a[0]==task]
   if not wins:continue
   _,seed,paths,wall=max(wins,key=lambda r:r[3][0]/r[3][1])
   from gym_clip import render_gym
   receipts=[json.loads((d/f'{task}-{seed}-{arm}.json').read_text()) for arm in ('original','edited')]
   films.append(render_gym(filename,title,seed,paths,wall,receipts))
  (out/'gym-videos.json').write_text(json.dumps(films,indent=2)+'\n')
