import fs from 'node:fs';
import path from 'node:path';
const [url,dir] = process.argv.slice(2);
const sock = new WebSocket(url);
await new Promise((resolve,reject) => { sock.onopen=resolve; sock.onerror=reject; });
let serial=0;
const pending=new Map();
sock.onmessage = ({data}) => {
  const reply=JSON.parse(data);
  if (!pending.has(reply.id)) return;
  const waiter=pending.get(reply.id);
  pending.delete(reply.id);
  if (reply.error) waiter.reject(new Error(reply.error.message)); else waiter.resolve(reply.result);
};
function call(method,params={}) {
  const id=++serial;
  return new Promise((resolve,reject) => {
    pending.set(id,{resolve,reject});
    sock.send(JSON.stringify({id,method,params}));
  });
}
const manifest=[];
let count=0;
do {
  const start=Date.now();
  const {data}=await call('Page.captureScreenshot',{format:'png',fromSurface:true,captureBeyondViewport:false,clip:{x:0,y:0,width:160,height:210,scale:2}});
  const end=Date.now();
  const file=String(count++).padStart(5,'0')+'.png';
  fs.writeFileSync(path.join(dir,file),Buffer.from(data,'base64'));
  manifest.push({file,start,end});
  if (count===1) fs.writeFileSync(path.join(dir,'ready'),'1');
  if (fs.existsSync(path.join(dir,'stop'))) break;
  await new Promise(r=>setTimeout(r,Math.max(0,125-(end-start))));
} while (count<2100);
fs.writeFileSync(path.join(dir,'frames.json'),JSON.stringify(manifest));
sock.close();
