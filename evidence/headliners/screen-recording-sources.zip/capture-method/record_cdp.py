"""Film two jointly successful cases, measuring each newly captured trial on its own clock."""
import hashlib,inspect,json,os,socket,subprocess,sys,time,urllib.request
from pathlib import Path
from types import SimpleNamespace
here=Path(__file__).resolve().parent;root=here.parents[2];repo=root/'work/publication/inkling-browser-weights'
sys.path.insert(0,str(repo/'benchmark'))
import gym as suite
import browsergym.core.env as benv
from PIL import Image
os.environ['INKLING_MLX_PYTHON']=str(repo/'.venv/bin/python')
os.environ['MINIWOB_URL']=(root/'work/browsergym/miniwob/miniwob/html/miniwob').as_uri()+'/'
paths={'original':Path.home()/'.cache/huggingface/hub/models--thinkingmachines--Inkling-2-Mini/snapshots/ed40e7da625f594fc9c4990f5f66be24873c22d7','edited':root/'work/publication/model'}
base=here/'runs';dest=here/'cdp-runs';dest.mkdir(exist_ok=True)
closed_socket=socket.socket();closed_socket.bind(('127.0.0.1',0));port=closed_socket.getsockname()[1];closed_socket.close()
getter=benv._get_global_playwright
def get_browser():
 pw=getter()
 def launch(**kwargs):
  kwargs['args']=[*kwargs.get('args',[]),'--remote-debugging-address=127.0.0.1',f'--remote-debugging-port={port}']
  return pw.chromium.launch(**kwargs)
 return SimpleNamespace(chromium=SimpleNamespace(launch=launch),selectors=pw.selectors)
benv._get_global_playwright=get_browser
def capture_start(page):
 session=page.context.new_cdp_session(page);target=session.send('Target.getTargetInfo')['targetInfo']['targetId'];session.detach()
 targets=json.load(urllib.request.urlopen(f'http://127.0.0.1:{port}/json/list',timeout=6))
 ws=next(row['webSocketDebuggerUrl'] for row in targets if row['id']==target)
 proc=subprocess.Popen(['node',str(here/'cdp-watch.mjs'),ws,str(folder)])
 for _ in range(300):
  if (folder/'ready').exists():return proc
  if proc.poll() is not None: raise RuntimeError(f'CDP recorder exited {proc.returncode}')
  time.sleep(.03)
 proc.terminate();raise TimeoutError('First screenshot')
def stop_capture(proc):
 (folder/'stop').touch();proc.wait(timeout=8)
 if proc.returncode:raise RuntimeError('CDP recorder stopped with error')
 frames=json.loads((folder/'frames.json').read_text())
 assert len(frames)>=2
 for item in [frames[0],frames[-1]]:
  with Image.open(folder/item['file']) as im:assert im.size==(320,420),im.size
src=inspect.getsource(suite.evaluate)
src=src.replace('        start=time.perf_counter()',"""        recorder=capture_start(page)
        wall_origin=time.time()
        start=time.perf_counter()""")
src=src.replace("        (out/f'{task}-{seed}-{arm}.json')","""        log['capture_start_unix_s']=wall_origin
        log['capture_end_unix_s']=wall_origin+log['elapsed_s']
        stop_capture(recorder)
        (out/f'{task}-{seed}-{arm}.json')""")
ctx=dict(vars(suite),capture_start=capture_start,stop_capture=stop_capture);exec(src,ctx);evaluate=ctx['evaluate']
def best_pair(task):
 pairs=[]
 for p in base.glob(task+'-*-original.json'):
  a=json.loads(p.read_text());b=json.loads(p.with_name(p.name.replace('-original','-edited')).read_text())
  if a['success'] and b['success']:pairs.append((a['elapsed_s']/b['elapsed_s'],a['seed']))
 return max(pairs)[1] if pairs else None
cases=[(t,best_pair(t)) for t in ('use-autocomplete','email-inbox')]
cases=[(t,seed) for t,seed in cases if seed is not None]
(dest/'selection.json').write_text(json.dumps(cases)+'\n')
workers={}
try:
 for arm in paths:workers[arm]=suite.inference_proc(str(paths[arm]))
 for task,seed in cases:
  for arm in ('edited','original'):
   stem=f'{task}-{seed}-{arm}';folder=dest/stem
   if (dest/(stem+'.json')).exists() and (folder/'frames.json').exists():continue
   folder.mkdir(exist_ok=True)
   for fname in ('stop','ready','frames.json'):(folder/fname).unlink(missing_ok=True)
   evaluate(task,seed,arm,workers[arm],dest)
finally:
 for w in workers.values():w.stdin.close();w.wait()
(dest/'done.json').write_text(json.dumps(cases)+'\n')
